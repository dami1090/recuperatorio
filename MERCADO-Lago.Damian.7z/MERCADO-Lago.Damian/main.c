#include <stdio.h>
#include <stdlib.h>
#include "lib.h"
#include "utn.h"
#define PUB 8
#define USU 4

int main()
{
    int aux;
    int auxP;

    char seguir='s';
    int opcion=0;
    EPublicacion publi[PUB];
    EUsuario usuario[USU];
    inicializarEstadoP( publi, PUB);
    inicializarEstado( usuario, USU);
    hardcoreUSU( usuario,USU);
    hardcorePUB(publi,PUB);
    while(seguir=='s')
    {
        printf("1- ALTA DE USUARIO \n");
        printf("2- MODIFICAR DATOS DEL USUARIO \n");
        printf("3- BAJA DE USUARIO\n");
        printf("4- PUBLICAR PRODUCTO\n");
        printf("5- MODIFICAR PUBLICACION\n");
        printf("6- CANCELAR PUBLICACION\n");
        printf("7- COMPRAR PRODUCTO\n");
        printf("8- LISTAR PUBLICACIONES DE USUARIO\n");
        printf("9- LISTAR PUBLICACIONES\n");
        printf("10- LISTAR USUARIOS\n");
        printf("11- USUARIOS CON MAS PUBLICACIONES\n");
        printf("12- Salir\n");

        scanf("%d",&opcion);

        switch(opcion)
        {
            case 1:
              aux = altaUsuario(usuario,USU);
               if(aux==1)
                {
                    printf("\tEl usuario se creo correctamente\n");
                    system("pause");
                    system("cls");
                }
                else if(aux==0)
                {
                    printf("\n\tno hay lugar para crea mas usuarios\n\n");
                    system("pause");
                    system("cls");
                }
                else if(aux==-1)
                {
                    printf("\n\t Creacion de usuario cancelada \n\n");
                    system("pause");
                    system("cls");
                }
                break;

            case 2:
                aux=modificarUsuario(usuario,USU);
                if(aux==2)
                {
                    printf("\n\tno se encontro el usuario\n");
                    system("pause");
                    system("cls");
                }
                else if(aux==-1)
                {
                    printf("\n\t Modificacion de usuario cancelada \n\n");
                    system("pause");
                    system("cls");
                }
                break;
            case 3:
                aux = eliminarUsuario(publi,usuario,PUB,USU);
                if(aux==1)
                {
                    printf("\tEl usuario se borro correctamente y sus publicaciones correspondientes tmb\n");
                    system("pause");
                    system("cls");
                }
                else if(aux==-1)
                {
                    printf("\tEl usuario o el password no eran correcto\n");
                    system("pause");
                    system("cls");
                }
                else if(aux==2)
                {
                    printf("\tno se encontro el usuario\n");
                    system("pause");
                    system("cls");

                }
                break;
            case 4:
                auxP = publicar(publi,usuario,PUB,USU);
                if(auxP==-1)
                {
                    printf("\n\t publicacion de producto cancelada/sin espacio suficiente \n\n");
                    system("pause");
                    system("cls");
                }
                else if(auxP==1)
                {
                    printf("\t se publico correctamente\n");
                    system("pause");
                    system("cls");
                }
                else if (auxP==2)
                {
                    printf("no hay espacio para publicar o no se encontro el usuario\n");
                    system("pause");
                    system("cls");
                }

                break;
            case 5:
                aux= modificarPublicacion(usuario,publi,USU,PUB);
                if(aux==2)
                {
                    printf("no se encontro el usuario\n");
                    system("pause");
                    system("cls");
                }
                else if(aux==1)
                {
                    printf("\t se modifico correctamente\n");
                    system("pause");
                    system("cls");
                }
                 if(aux==-1)
                {
                    printf("\n\t modificacion de producto cancelada \n\n");
                    system("pause");
                    system("cls");
                }


                break;
            case 6:
                aux=cancelarPublicacion(usuario,publi,PUB,USU);
                 if(aux==2)
                {
                    printf("no se encontro el usuario\n");
                    system("pause");
                    system("cls");
                }
                else if(aux==1)
                {
                    printf("\t se cancelo correctamente\n");
                    system("pause");
                    system("cls");
                }
                 if(aux==-1)
                {
                    printf("\n\t la publicacion NO fue cancelada \n\n");
                    system("pause");
                    system("cls");
                }
                break;
            case 7:
                aux=comprarProducto(usuario,publi,PUB,USU);
                if(aux==2)
                {
                    printf("no se encontro el producto\n");
                    system("pause");
                    system("cls");
                }
                else if(aux==1)
                {
                    printf("\t se realizo correctamente la compra\n");
                    system("pause");
                    system("cls");
                }
                 if(aux==-1)
                {
                    printf("\n\t operacion cancelada \n\n");
                    system("pause");
                    system("cls");
                }
                break;
            case 8:
                listarPublicacionesDeUsuario(usuario,publi,PUB,USU);
                break;
            case 9:
                listarTodo(publi,PUB);
                break;
            case 10:
                listarUsuarios(usuario,publi,USU,PUB);
                break;
            case 11:
                masPublicaciones(usuario,publi,USU,PUB);
                break;
            case 12:
                seguir = 'n';
                break;

                 default:
                system("cls");
            printf("\n\tOpcion invalida\n\n");

            break;
        }
    }
}
