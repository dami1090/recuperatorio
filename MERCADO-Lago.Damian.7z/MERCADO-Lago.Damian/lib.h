#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
typedef struct{
    char usuario[50];
    char password[50];
    int idProducto;
    int ventaTotal;
    float calificacionTotal;
    int estadoUsuario;

}EUsuario;

typedef struct{
    char nombreProducto[50];
    char usuario[50];
    int idProducto;
    int cantVendida;
    float precio;
    float calificacion;
    int stock;
    int estadoPublicar;
}EPublicacion;
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */
 void masPublicaciones(EUsuario usuarios[],EPublicacion publi[],int u,int p);
 void hardcorePUB(EPublicacion publi[],int p);
 void hardcoreUSU(EUsuario usuario[],int u);
 int cancelarPublicacion(EUsuario usuario[],EPublicacion publi[],int p,int u);
void listarTodo(EPublicacion publi[],int p);
void listarPublicacionesDeUsuario(EUsuario usuario[],EPublicacion publi[],int p,int u);
int comprarProducto(EUsuario usuario[],EPublicacion publi[],int p,int u);
void listarUsuarios(EUsuario usuario[],EPublicacion publi[],int u, int p);
int obtenerEspacioLibrePro(EPublicacion publi[], int t);

void inicializarEstadoP(EPublicacion lista[], int t);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

void inicializarEstado(EUsuario usuario[], int t);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int altaUsuario(EUsuario lista[],int t);

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */
int modificarUsuario(EUsuario usuario[],int t);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int buscarProducto(EPublicacion publi[], int t,char aux[]);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int buscarUsuario(EUsuario usuario[], int t,char aux[]);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int publicar(EPublicacion publi[],EUsuario usuario[],int p,int u);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int eliminarUsuario(EPublicacion publi[],EUsuario usuario[],int p,int u);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

void listaProducto(EPublicacion publi);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int modificarPublicacion(EUsuario usuario[],EPublicacion publi[],int u, int p);

#endif // FUNCIONES_H_INCLUDED
