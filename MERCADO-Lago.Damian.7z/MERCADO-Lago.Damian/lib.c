#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <ctype.h>
#include "lib.h"
#include "utn.h"

void hardcorePUB(EPublicacion publi[],int p)
{
    int i;

    char auxnombreProducto[][50]= {"sillon","mesa","ropero","calefon","beagle","memoria RAM","mouse","teclado"};
    char auxusuario[][50]= {"dami1090","dami1090","piccolo","cheetara","leon","leon","piccolo","dami1090"};
    int auxidProducto[]= {100,101,102,103,104,105,106,107};
    int auxcantVendida[]= {7,2,5,6,3,12,15,1};
    float auxprecio[]= {950,850,600,999,2500,1550,150,230};
    float auxcalificacion[]= {9,5,6,7,7,7,2,8};
    int auxstock[]= {14,5,6,2,3,9,6,19};
    int auxestadoPublicar[]= {1,1,1,1,1,1,1,1};

    for(i=0; i<p; i++)
    {
        strcpy(publi[i].nombreProducto,auxnombreProducto[i]);
        strcpy(publi[i].usuario,auxusuario[i]);
        publi[i].idProducto=auxidProducto[i];
        publi[i].cantVendida=auxcantVendida[i];
        publi[i].precio=auxprecio[i];
        publi[i].calificacion=auxcalificacion[i];
        publi[i].stock=auxstock[i];
        publi[i].estadoPublicar=auxestadoPublicar[i];

    }
}

void hardcoreUSU(EUsuario usuario[],int u)
{
    int i;
    int auxventaTotal[]= {10,6,15,3};
    char auxusuario[][50]= {"dami1090","cheetara","leon","piccolo"};
    char auxpassword[][50]= {"ikm333","neverdie18","56hunting","namek4rules"};
    int auxidProducto[]= {{100,101,107},{103},{104,105},{106,102}};
    float auxcalificacionTotal[]= {22,7,14,8};
    int auxestadoUsuario[]= {1,1,1,1};

    for(i=0; i<u; i++)
    {
        strcpy(usuario[i].usuario,auxusuario[i]);
        strcpy(usuario[i].password,auxpassword[i]);
        usuario[i].idProducto=auxidProducto[i];
        usuario[i].calificacionTotal=auxcalificacionTotal[i];
        usuario[i].estadoUsuario=auxestadoUsuario[i];
    }
}
void inicializarEstado(EUsuario usuario[], int t)
{
    int i;
    for(i=0; i<t; i++)
    {
        usuario[i].estadoUsuario = 0;
    }
}
void inicializarEstadoP(EPublicacion lista[], int t)
{
    int i;
    for(i=0; i<t; i++)
    {
        lista[i].estadoPublicar = 0;
    }
}

int obtenerEspacioLibre(EUsuario usuario[], int t)
{
    int i;
    for(i = 0; i < t; i++)
    {
        if(usuario[i].estadoUsuario == 0)
        {
            return i;
        }
    }

    return -1;
}

int obtenerEspacioLibrePro(EPublicacion publi[], int t)
{
    int i;
    for(i = 0; i < t; i++)
    {
        if(publi[i].estadoPublicar == 0)
        {
            return i;
        }
    }

    return -1;
}

int altaUsuario(EUsuario usuario[],int t)
{

    int i;
    int lugar;
    char resp;
    lugar = obtenerEspacioLibre(usuario, t);
    if (lugar==-1)
    {
        printf("\n\tsin espacio para seguir almacenando usuarios\n");
        return;
    }

    for(i=0; i<t; i++)
    {
        if(usuario[i].estadoUsuario==0)
        {

            printf("Ingrese un nombre para usuario: \n");
            fflush(stdin);
            gets(usuario[i].usuario);
            printf("Ingrese el password: \n");
            fflush(stdin);
            gets(usuario[i].password);
            printf("el usuario es? %s \n",usuario[i].usuario);
            printf("el password es? %s \n",usuario[i].password);

            resp = getChar(" estos datos son correctos? s/n\n");
            if(resp == 's')
            {

                usuario[i].estadoUsuario = 1;


                printf("Usuario es: %s \n",usuario[i].usuario);
                printf("Password es: %s \n",usuario[i].password);
                system("pause");
                return 1;

            }
            else if (resp == 'n')
            {
                return -1;
            }

        }
    }
    return 0;
}

int modificarUsuario(EUsuario usuario[],int t)
{

    char auxUsuario[50];
    char auxPassword[50];
    char resp;
    int posicion;
    printf("ingrese  usuario: \n");
    fflush(stdin);
    gets(auxUsuario);
    posicion=buscarUsuario(usuario,t,auxUsuario);
    if(posicion!=-1)
    {

        printf("el usuario es: %s \n",usuario[posicion].usuario);
        printf("el password es: %s \n",usuario[posicion].password);
        resp=getChar("es el usuario que desea modificar?(s/n)\n");
        if(resp=='s')
        {

            printf("Ingrese un nombre para usuario: \n");
            fflush(stdin);
            gets(auxUsuario);
            printf("Ingrese el password: \n");
            fflush(stdin);
            gets(auxPassword);
            printf("el nuevo usuario es: %s \n",auxUsuario);
            printf("el nuevo password es: %s \n",auxPassword);

            resp = getChar(" estos datos son correctos? s/n\n");

            if(resp == 's')
            {
                strcpy(usuario[posicion].usuario,auxUsuario);
                strcpy(usuario[posicion].password,auxPassword);
                system("cls");
                return 1;

            }
            else if(resp =='n')
            {
                return -1;
            }


        }

    }

    return 2;

}

int buscarProducto(EPublicacion publi[], int t,char aux[])
{
    int i;
    int index;
    for(i=0; i<t; i++)
    {
        if (publi[i].estadoPublicar==1 && stricmp(publi[i].usuario,aux)==0)
        {
            index = i;
            break;
        }
        else
        {
            index = -1;
        }

    }
    return index;
}

int buscarUsuario(EUsuario usuario[], int t,char aux[])
{
    int i;
    int index;
    for(i=0; i<t; i++)
    {
        if (usuario[i].estadoUsuario==1 && stricmp(usuario[i].usuario,aux)==0)
        {
            index = i;
            break;
        }
        else
        {
            index = -1;
        }

    }
    return index;
}

int publicar(EPublicacion publi[],EUsuario usuario[],int p,int u)
{
    int flag=2;
    char resp;
    int posicion;
    int posicionPro;
    char auxUsuario[50];
    char auxProducto[50];
    float auxPrecio;
    int auxStock;

    printf("ingrese  usuario: \n");
    fflush(stdin);
    gets(auxUsuario);
    posicion=buscarUsuario(usuario,u,auxUsuario);

    if(posicion!=-1)
    {

        printf("Ingrese el nombre para el producto: \n");
        fflush(stdin);
        gets(auxProducto);
        printf("ingrese precio para el producto: \n");
        scanf("%f",&auxPrecio);
        printf("ingrese stock a disposicion para el producto en cuestion: \n");
        scanf("%d",&auxStock);

        printf("el nombre del producto es: %s\n",auxProducto);
        printf("el precio del producto es: %.2f\n",auxPrecio);
        printf("el stock de dicho producto es: %d\n",auxStock);

        resp = getChar(" estos datos son correctos? s/n\n");

        if(resp == 's')
        {
            posicionPro=obtenerEspacioLibrePro(publi, p);
            if(posicionPro!=-1)
            {

                strcpy(publi[posicionPro].usuario,usuario[posicion].usuario);
                strcpy(publi[posicionPro].nombreProducto,auxProducto);
                publi[posicionPro].precio=auxPrecio;
                publi[posicionPro].stock=auxStock;
                publi[posicionPro].cantVendida=0;
                publi[posicionPro].idProducto=posicionPro+1;
                publi[posicionPro].estadoPublicar=1;
                system("cls");
                flag=1;
                return flag;

            }
            else if(resp =='n')
            {

                flag=-1;
                return flag;

            }
        }
        else
        {
            flag=2;
            return flag;
        }

    }
    return;
}
int eliminarUsuario(EPublicacion publi[],EUsuario usuario[],int p,int u)
{
    int i;
    char resp;
    int posicion;
    char auxUsuario[50];
    char auxPassword[50];

    printf("ingrese  usuario: \n");
    fflush(stdin);
    gets(auxUsuario);
    posicion=buscarUsuario(usuario,u,auxUsuario);

    if(posicion!=-1)
    {
        printf("el usuario es: %s\n",auxUsuario);
        resp=getChar("es el usuario deseado? s/n");
        if(resp =='s')
        {

            printf("Ingrese el password: \n");
            fflush(stdin);
            gets(auxPassword);
            if(strcmp(usuario[posicion].password,auxPassword)==0)
            {

                for(i=0; i<p; i++)
                {
                    if(usuario[posicion].idProducto == publi[i].idProducto)
                    {
                        publi[i].estadoPublicar=3;
                    }

                }
                usuario[posicion].estadoUsuario=3;
                return 1;
            }
            else
            {
                printf("password incorrecto\n");
                return -1;
            }
        }
        else if(resp == 'n')
            return -1;

    }
    else
        return 2;

}

void listaProducto(EPublicacion publi)
{

    printf("Nombre del usuario q lo publica: %s\n",publi.usuario);
    printf("\tProducto nombre: %s\n",publi.nombreProducto);
    printf("\tProducto ID: %d\n",publi.idProducto);
    printf("\tProducto precio: %.2f\n",publi.precio);
    printf("\tProducto stock: %d\n",publi.stock);
    printf("\t cantidad de veces vendido: %d\n",publi.cantVendida);
    printf("\n---------------------------------------------------------\n");


}


int modificarPublicacion(EUsuario usuario[],EPublicacion publi[],int u, int p)
{
    int i;
    int g;
    int j=0;
    char resp;
    int posicion;
    char auxUsuario[50];
    int auxID;
    float auxPre;
    int auxStock;


    printf("ingrese  usuario: \n");
    fflush(stdin);
    gets(auxUsuario);
    posicion=buscarUsuario(usuario,u,auxUsuario);

    if(posicion!=-1)
    {
        for(i=0; i<p; i++)
        {
            if(strcmp(usuario[posicion].usuario,publi[i].usuario)==0 && (publi[i].estadoPublicar!=0))
            {
                j++;
                printf("\t Producto publicado numero: %d\n",j);
                listaProducto(publi[i]);

            }

        }

        printf("ingrese el ID del producto q desea modificar");
        scanf("%d",&auxID);

        for(g=0; g<p; g++)
        {
            if(publi[g].idProducto==auxID)
            {
                printf("ingrese nuevo precio\n");
                scanf("%f",&auxPre);
                printf("ingrese nuevo stock\n");
                scanf("%d",&auxStock);
                printf("el nuevo precio es: %.2f\n",auxPre);
                printf("el nuevo stock es: %d\n",auxStock);
                resp=getChar("esta seguro que desea modificar? s/n\n");
                if(resp=='s')
                {
                    publi[g].precio=auxPre;
                    publi[g].stock=auxStock;
                    return 1;
                }
                else if(resp=='n')
                    return -1;
            }
        }
    }

    return 2;


}
int comprarProducto(EUsuario usuario[],EPublicacion publi[],int p,int u)
{

    int auxIDpro;
    int i;
    int g;
    char resp;
    int auxCant;
    float auxCalificacion;
    printf("ingrese ID del producto a comprar: \n");
    scanf("%d",&auxIDpro);
    for(i=0; i<p; i++)
    {
        if(publi[i].idProducto==auxIDpro && publi[i].stock!=0)
        {
            listaProducto(publi[i]);
            resp=getChar("es el producto q desea comprar? s/n\n");
            if(resp=='s')
            {
                printf("cuantos productos desea comprar? \n");
                scanf("%d",&auxCant);
                if(auxCant<=publi[i].stock)
                {
                    publi[i].stock=publi[i].stock-auxCant;
                    publi[i].cantVendida++;
                    printf("q calificacion merece el vendedor");
                    scanf("%f",&auxCalificacion);
                    publi[i].calificacion+=auxCalificacion;

                    return 1;
                }
                else
                {
                    printf("no hay stock suficiente, reintente operacion");
                    system("cls");
                    return -1;
                }
            }
            else if(resp=='n')
                return 2;

        }
    }

    return 2;
}

void listarPublicacionesDeUsuario(EUsuario usuario[],EPublicacion publi[],int p,int u)
{
    int i;
    char auxUsuario[50];
    char resp;
    int posicion;

    printf("ingrese  usuario: \n");
    fflush(stdin);
    gets(auxUsuario);
    posicion=buscarUsuario(usuario,u,auxUsuario);

    if(posicion!=-1)
    {
        for(i=0; i<p; i++)
        {
            if(strcmp(usuario[posicion].usuario,publi[i].usuario)==0 && (publi[i].estadoPublicar!=0))
            {
                listaProducto(publi[i]);

            }


        }
    }
}

void listarTodo(EPublicacion publi[],int p)
{
    int i;
    for(i=0; i<p; i++)
    {
        if(publi[i].estadoPublicar!=0)
        {
            listaProducto(publi[i]);
        }
    }

}
void listarUsuarios(EUsuario usuario[],EPublicacion publi[],int u, int p)
{
    int i;
    int g;
    float prom=0;
    int ventaTotal=0;
    float calificacionTotal=0;
    for(i=0; i<u; i++)
    {
        if(usuario[i].estadoUsuario!=0)
        {

            for(g=0; g<p; g++)
            {
                if(usuario[i].ventaTotal>usuario[g].ventaTotal)
                {
                    ventaTotal+=usuario[i].ventaTotal;
                    calificacionTotal+=usuario[i].calificacionTotal;
                }
                else if(usuario[i].ventaTotal<usuario[g].ventaTotal)
                {
                    ventaTotal+=usuario[g].ventaTotal;
                    calificacionTotal+=usuario[g].calificacionTotal;
                }

            }

            printf("usuario: %s\n",usuario[i].usuario);

            prom=calificacionTotal/ventaTotal;
            printf("Promedio de calificacion del usuario: %.2f\n\n",&prom);

        }
    }
    system("pause");
}
int cancelarPublicacion(EUsuario usuario[],EPublicacion publi[],int p,int u)
{

    int i;
    int g;
    int j=0;
    char resp;
    int posicion;
    char auxUsuario[50];
    int auxID;



    printf("ingrese  usuario: \n");
    fflush(stdin);
    gets(auxUsuario);
    posicion=buscarUsuario(usuario,u,auxUsuario);

    if(posicion!=-1)
    {
        for(i=0; i<p; i++)
        {
            if(strcmp(usuario[posicion].usuario,publi[i].usuario)==0 && (publi[i].estadoPublicar!=0))
            {
                j++;
                printf("\t Producto publicado numero: %d\n",j);
                listaProducto(publi[i]);

            }

        }

        printf("ingrese el ID del producto q desea cancelar su publicacion\n");
        scanf("%d",&auxID);

        for(g=0; g<p; g++)
        {
            if(publi[g].idProducto==auxID)

            {


                printf("el producto es %s\n",publi[g].nombreProducto);
                resp=getChar("esta seguro que desea modificar? s/n\n");
                if(resp=='s')
                {
                    publi[g].estadoPublicar=3;

                    return 1;
                }
                else if(resp=='n')
                    return -1;
            }
        }
    }

    return 2;

}


void masPublicaciones(EUsuario usuarios[],EPublicacion publi[],int u,int p)
{
    int i;
    int g;
    int contadorPubli;
    int contadorUsuario;
    int auxcontadorPubli;
    int auxcontadorUsuario;
    char maxVenta[50];
    char maxVenta2[50];

    for(i=0; i<u; i++)
    {

        if(usuarios[i].usuario!=0);
        {
            for(g=0; g<p; g++)
            {
                if(strcpy(publi[g].usuario,usuarios[i].usuario)==0)
                {
                    contadorPubli++;
                    contadorUsuario=i;

                }

            }

        }

    }
